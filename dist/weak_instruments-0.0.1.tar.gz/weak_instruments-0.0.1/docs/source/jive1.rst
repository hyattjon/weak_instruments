jive1
=====

.. automodule:: weak_instruments.jive1
   :members:
   :undoc-members:
   :show-inheritance: