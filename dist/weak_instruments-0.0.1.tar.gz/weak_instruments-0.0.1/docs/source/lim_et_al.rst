lim_et_al
=========

.. automodule:: weak_instruments.lim_et_al
   :members:
   :undoc-members:
   :show-inheritance: