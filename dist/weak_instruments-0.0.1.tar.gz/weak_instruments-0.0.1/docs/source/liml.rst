liml
====

.. automodule:: weak_instruments.liml
   :members:
   :undoc-members:
   :show-inheritance: