# Mikusheva and Sun (2024) pre-test for many and weak instruments
from repo import *



if __name__=="__main__":
    pass