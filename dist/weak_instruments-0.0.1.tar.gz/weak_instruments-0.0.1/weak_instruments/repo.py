


def standard_errors():
    pass

def F_stat():
    pass

def r_squared():
    pass

def adjusted_r_squared():
    pass

def root_mse():
    pass

def pvals():
    pass

def tstats():
    pass

def cis():
    pass






if __name__ == "__main__":
    pass

