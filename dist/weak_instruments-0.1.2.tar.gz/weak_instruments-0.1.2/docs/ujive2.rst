ujive2
======

.. automodule:: weak_instruments.ujive2
   :members:
   :undoc-members:
   :show-inheritance: