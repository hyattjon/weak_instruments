ijive
=====

.. automodule:: weak_instruments.ijive
   :members:
   :undoc-members:
   :show-inheritance: