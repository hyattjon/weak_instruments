cjive
=====

.. automodule:: weak_instruments.cjive
   :members:
   :undoc-members:
   :show-inheritance: