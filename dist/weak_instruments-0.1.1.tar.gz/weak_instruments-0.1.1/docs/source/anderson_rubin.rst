anderson_rubin
==============

.. automodule:: weak_instruments.anderson_rubin
   :members:
   :undoc-members:
   :show-inheritance: