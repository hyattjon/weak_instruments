lagrange_multiplier
===================

.. automodule:: weak_instruments.lagrange_multiplier
   :members:
   :undoc-members:
   :show-inheritance: