jive2
=====

.. automodule:: weak_instruments.jive2
   :members:
   :undoc-members:
   :show-inheritance: