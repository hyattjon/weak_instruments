hful
====

.. automodule:: weak_instruments.hful
   :members:
   :undoc-members:
   :show-inheritance: