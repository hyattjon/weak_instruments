tsls
====

.. automodule:: weak_instruments.tsls
   :members:
   :undoc-members:
   :show-inheritance: