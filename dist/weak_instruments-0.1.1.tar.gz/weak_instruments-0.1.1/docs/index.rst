Welcome to weak_instruments's documentation!
============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   liml
   jive1
   jive2
   ujive1
   ujive2
   ijive
   cjive
   sjive
   hful
   lagrange_multiplier
   anderson_rubin
   tsls


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`