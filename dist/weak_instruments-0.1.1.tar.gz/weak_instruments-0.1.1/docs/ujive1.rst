ujive1
======

.. automodule:: weak_instruments.ujive1
   :members:
   :undoc-members:
   :show-inheritance: