sjive
=====

.. automodule:: weak_instruments.sjive
   :members:
   :undoc-members:
   :show-inheritance: