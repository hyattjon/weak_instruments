#  Lim et al. conditional linear combination test for inference on many weak instruments
from repo import *


if __name__=="__main__":
    pass