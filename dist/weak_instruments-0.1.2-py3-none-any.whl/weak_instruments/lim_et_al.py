#  Lim et al. conditional linear combination test for inference on many weak instruments



if __name__=="__main__":
    pass